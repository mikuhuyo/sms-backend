export interface PageInfo {
  pageNum: number;
  pageSize: number;
  total: number;
}